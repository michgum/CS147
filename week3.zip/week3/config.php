<?php
<<<<<<< HEAD
$link = mysql_connect('mysql-user-master.stanford.edu', 'ccs147mgumport', 'bohraili');
mysql_select_db('c_cs147_mgumport');
=======
$link = mysql_connect('mysql-user-master.stanford.edu', 'ccs147rakasaka', 'ofairahf');
mysql_select_db('c_cs147_rakasaka');
>>>>>>> b3dacea09ff430bf4988b594f3098ed8216df35c
?>