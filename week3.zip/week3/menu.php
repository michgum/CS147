<div class="box box1">
	<a href="index.php" class="coda">Books</a>
</div>
<div class="box box1">
	<a href="order.php" class="coda">Order</a>
</div>